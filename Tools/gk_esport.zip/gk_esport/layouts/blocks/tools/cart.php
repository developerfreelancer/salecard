<?php

	// no direct access
	defined('_JEXEC') or die('Restricted access');
	
?>

<?php if($this->modules('cart')) : ?>		
<div id="gkAjaxCart"></div>
<?php endif; ?>	