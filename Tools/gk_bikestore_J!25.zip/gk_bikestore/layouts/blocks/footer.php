<?php

// No direct access.
defined('_JEXEC') or die;

?>

<footer class="gkFooter">
	<?php if($this->API->modules('footer_nav')) : ?>
	<jdoc:include type="modules" name="footer_nav" style="<?php echo $this->module_styles['footer_nav']; ?>" />
	<?php endif; ?>
		
	<?php if($this->API->get('copyrights', '') !== '') : ?>
		<p><?php echo $this->API->get('copyrights', ''); ?></p>
	<?php else : ?>
		<p>Template Design &copy; <a href="http://www.gavick.com" title="Joomla Templates">Joomla Templates</a> GavickPro. All rights reserved.</p>
	<?php endif; ?>
</footer>